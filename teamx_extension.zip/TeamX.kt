package eu.kanade.tachiyomi.extension.arabic.teamx

import eu.kanade.tachiyomi.multisrc.madara.Madara

class TeamX : Madara(
    "Team-X",
    "https://www.olympustaff.com",
    "ar"
)